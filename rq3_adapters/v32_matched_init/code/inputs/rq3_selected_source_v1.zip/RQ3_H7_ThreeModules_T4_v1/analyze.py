"""Paired video bootstrap conditional on three fixed seeds; exploratory inference."""
import argparse
import csv
from pathlib import Path
import numpy as np
from sklearn.metrics import average_precision_score
from study import load, save, sha, SEEDS, validate_inputs, object_sha


def paired_bootstrap(labels, groups, a, b, draws=2000, rng_seed=20261102):
    labels, groups = np.asarray(labels), np.asarray(groups)
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    if (draws < 100 or a.shape != b.shape or a.shape != (3, len(labels))
            or groups.shape != labels.shape or set(groups) != {0,1,2}
            or set(labels) != {0,1} or not np.isfinite(a).all() or not np.isfinite(b).all()
            or np.any((a < 0) | (a > 1)) or np.any((b < 0) | (b > 1))):
        raise ValueError('Require paired probabilities, 3 seeds and 3 lead groups.')
    strata = [np.flatnonzero((groups == g) & (labels == y)) for g in (0,1,2) for y in (0,1)]
    if any(len(x) == 0 for x in strata):
        raise ValueError('Each lead-time x label stratum needs observations.')
    def delta(indices):
        result = []
        for g in (0,1,2):
            ix = indices[groups[indices] == g]
            result.append(float(np.mean([average_precision_score(labels[ix], a[s,ix]) -
                                         average_precision_score(labels[ix], b[s,ix]) for s in range(3)])))
        return [result[2], float(np.mean(result))]
    rng = np.random.default_rng(rng_seed)
    measured = delta(np.arange(len(labels)))
    boot = np.array([delta(np.concatenate([rng.choice(ix, len(ix), replace=True) for ix in strata]))
                     for _ in range(draws)])
    return {name:dict(delta=measured[i], ci95=np.quantile(boot[:,i],[.025,.975]).tolist())
            for i,name in enumerate(('AP@1.5s','mAP'))}


def prediction_matrix(out, arm, ids):
    rows = []
    for seed in SEEDS:
        run=Path(out)/arm/('seed_%d'%seed)/'run'
        path=run/'test_predictions.json'
        seal=load(run/'evaluation_complete.json')
        if seal.get('complete') is not True or seal.get('files',{}).get('test_predictions.json')!=sha(path):
            raise ValueError('Unsealed/changed predictions: %s seed %d'%(arm,seed))
        values = load(path)
        mapping = {v['id']:float(v['score']) for v in values}
        if len(mapping) != len(values) or set(mapping) != set(ids):
            raise ValueError('Missing/duplicate/extra test predictions: %s seed %d'%(arm,seed))
        rows.append([mapping[i] for i in ids])
    return np.array(rows)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',required=True)
    parser.add_argument('--draws',type=int,default=2000)
    args=parser.parse_args()
    inputs=validate_inputs(load(args.inputs));out=Path(inputs['out_root'])
    # Final summaries only exist after every declared arm/seed was scored.
    load(out/'summary.json')
    from study import BASE
    with (BASE/'metadata_snapshot/solution.csv').open(encoding='utf-8-sig',newline='') as stream:
        solution=list(csv.DictReader(stream))
    if len(solution)!=1344 or len({r['id'] for r in solution})!=1344:
        raise ValueError('Expected exact 1344-video solution.')
    ids=[r['id'] for r in solution]
    y=np.array([int(r['target']) for r in solution]);g=np.array([int(r['group']) for r in solution])
    b=prediction_matrix(out,'b0',ids)
    results={arm+'-b0':paired_bootstrap(y,g,prediction_matrix(out,arm,ids),b,args.draws)
             for arm in inputs['arms']}
    save(out/'paired_intervals.json',dict(draws=args.draws,results=results,
         study_contract_sha256=object_sha(load(out/'study_contract.json')),
         sampling='paired video resampling stratified lead group x label; same draw across models and fixed seeds',
         scope='conditional on these 3 training seeds; not all training variability',
         interpretation='exploratory; prior test inspection and multiple comparisons disclosed'))


if __name__=='__main__':
    main()
