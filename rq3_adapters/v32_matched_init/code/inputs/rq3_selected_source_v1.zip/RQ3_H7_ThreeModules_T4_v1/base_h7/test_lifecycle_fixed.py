"""Synthetic recovery fixtures only. Never interpreted as Nexar scores or weights."""
import json
import os
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

import medium_ops as ops
import run_rq2 as queue
from checkpoint_safety import commit_snapshot
from repro import run_contract
from rq2_profile import VARIANT,protocol,scientific_profile
from training_state import assert_committed,archive_uncommitted,atomic_json


def make_committed(root,seed=42,epoch=50,variant=VARIANT,best='best_fixture.pth'):
    run=Path(root)/variant/('seed_%d'%seed)/'run';run.mkdir(parents=True,exist_ok=True)
    settings=dict(seed=seed,epochs=50,batch_per_gpu=2,effective_batch_size=16,world_size=1,amp=True)
    contract=run_contract(settings);contract.update(protocol=protocol(variant),rq2=scientific_profile(variant))
    status=dict(complete=epoch==50,completed_epochs=epoch,target_epochs=50,best_checkpoint=best)
    atomic_json(run/'run_manifest.json',dict(contract=contract))
    atomic_json(run/'training_status.json',status)
    for name in (best,'resume_latest.pth','rng_epoch%d_rank0.pth'%epoch):
        (run/name).write_bytes(b'SYNTHETIC_NOT_TORCH_WEIGHTS')
    (run/'validation_history.jsonl').write_text('\n'.join(json.dumps(dict(epoch=e,metrics={'mAUC@':.8,'mAP@':.7}))
                                                for e in range(1,epoch+1))+'\n',encoding='utf-8')
    commit_snapshot(run)
    return run,status,contract


class FixedLifecycleTests(unittest.TestCase):
    def test_complete_requires_all_artifacts(self):
        with tempfile.TemporaryDirectory() as folder:
            run,status,_=make_committed(folder)
            self.assertTrue(assert_committed(run,status,True))
            (run/status['best_checkpoint']).unlink()
            self.assertFalse(ops.all_training_complete(Path(folder),[42]))

    def test_metadata_only_never_opens_test(self):
        with tempfile.TemporaryDirectory() as folder:
            run,status,_=make_committed(folder)
            (run/'resume_latest.pth').unlink()
            self.assertFalse(ops.all_training_complete(Path(folder),[42]))

    def test_modified_checkpoint_rejected_before_evaluation(self):
        with tempfile.TemporaryDirectory() as folder:
            run,status,_=make_committed(folder)
            assert_committed(run,status)
            p=run/status['best_checkpoint'];p.write_bytes(b'CORRUPTED_SAVED_WEIGHTS')
            with self.assertRaisesRegex(ValueError,'differs from committed'):assert_committed(run,status)

    def test_orphan_checkpoint_without_contract_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as folder:
            run=Path(folder)/VARIANT/'seed_42/run';run.mkdir(parents=True)
            (run/'best_unknown.pth').write_bytes(b'preserve')
            with self.assertRaisesRegex(ValueError,'without its training contract'):
                queue.state(Path(folder),VARIANT,42)
            self.assertEqual((run/'best_unknown.pth').read_bytes(),b'preserve')

    def test_history_missing_or_duplicate_epoch_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            run,status,_=make_committed(folder)
            p=run/'validation_history.jsonl';original=p.read_text()
            p.write_text('\n'.join(original.splitlines()[:-1]))
            with self.assertRaisesRegex(ValueError,'every committed epoch'):assert_committed(run,status)
            p.write_text(original+original.splitlines()[-1]+'\n')
            with self.assertRaisesRegex(ValueError,'every committed epoch'):assert_committed(run,status)

    def test_nonfinite_selection_metric_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            run,status,_=make_committed(folder)
            p=run/'validation_history.jsonl';p.write_text(p.read_text().replace('0.8','NaN',1))
            with self.assertRaisesRegex(ValueError,'non-finite'):assert_committed(run,status)

    def test_evaluate_rolls_back_but_never_launches_training(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);run,status,_=make_committed(root,epoch=49)
            atomic_json(run/'training_status.json',dict(status,complete=True,completed_epochs=50))
            with patch.object(ops,'child') as child:
                with self.assertRaisesRegex(ValueError,'50 committed'):
                    ops.queue(root/'data',root,root/'runtime',[42],time.time()+60,'evaluate')
                child.assert_not_called()
            self.assertEqual(queue.load(run/'training_status.json')['completed_epochs'],49)

    def test_all_selected_seeds_checked_before_first_test(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);make_committed(root,42,50);make_committed(root,43,49)
            with patch.object(ops,'child') as child:
                with self.assertRaises(ValueError):
                    ops.queue(root/'data',root,root/'runtime',[42,43],time.time()+60,'evaluate')
                child.assert_not_called()

    def test_evaluate_command_has_no_train_flag(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);make_committed(root)
            with patch.object(ops,'child') as child:
                ops.queue(root/'data',root,root/'runtime',[42],time.time()+60,'evaluate')
            command=[str(x) for x in child.call_args.args[0]]
            self.assertIn('--evaluate-only',command);self.assertNotIn('--train',command)

    def test_interrupted_epoch_zero_is_preserved_and_restarted(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder);output=base/'out';(base/'data').mkdir()
            run,status,contract=make_committed(output,epoch=1)
            for name in ('training_status.json','safe_resume_snapshot.zip','resume_latest.pth','rng_epoch1_rank0.pth','validation_history.jsonl'):
                (run/name).unlink()
            before=(run/'run_manifest.json').read_bytes();commands=[]
            class Captured(RuntimeError):pass
            def child(command,**kw):
                if Path(command[1]).name=='run_vast.py':commands.append(command);raise Captured()
            with patch.object(queue,'verify_package'),patch.object(queue,'run_checked',side_effect=child):
                with self.assertRaises(Captured):
                    queue.main(['--data-root',str(base/'data'),'--output-root',str(output),
                                '--runtime-root',str(base/'runtime'),'--total-hours','1','--seeds','42','--train','--validation-only'])
            preserved=list(run.parent.glob('run_uncommitted_*'))
            self.assertEqual(len(preserved),1)
            self.assertEqual((preserved[0]/'run_manifest.json').read_bytes(),before)
            self.assertIn('--train',commands[0]);self.assertNotIn('--resume-root',commands[0])

    def test_unknown_contract_not_archived_automatically(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);run,_,_=make_committed(root)
            (run/'training_status.json').unlink();(run/'safe_resume_snapshot.zip').unlink()
            manifest=queue.load(run/'run_manifest.json');manifest['contract']['seed']=43
            atomic_json(run/'run_manifest.json',manifest)
            with self.assertRaisesRegex(ValueError,'Wrong protocol'):queue.state(root,VARIANT,42)
            self.assertTrue(run.exists())

    def test_possible_committed_recovery_never_discarded(self):
        with tempfile.TemporaryDirectory() as folder:
            run,_,_=make_committed(folder)
            with self.assertRaises(ValueError):archive_uncommitted(run)
            self.assertTrue((run/'safe_resume_snapshot.zip').is_file())

    def test_atomic_settings_recovers_truncated_json(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'settings.json';path.write_text('{interrupted')
            atomic_json(path,{'valid':True})
            self.assertEqual(json.loads(path.read_text()),{'valid':True})

    def test_partial_first_checkpoint_save_is_preserved(self):
        with tempfile.TemporaryDirectory() as folder:
            run,_,_=make_committed(folder,epoch=1)
            (run/'training_status.json').unlink();(run/'safe_resume_snapshot.zip').unlink()
            destination=archive_uncommitted(run)
            self.assertTrue((destination/'resume_latest.pth').exists())
            self.assertFalse(run.exists())

    def test_later_epoch_without_metadata_is_not_restarted(self):
        with tempfile.TemporaryDirectory() as folder:
            run,_,_=make_committed(folder,epoch=17)
            (run/'training_status.json').unlink();(run/'safe_resume_snapshot.zip').unlink()
            with self.assertRaises(ValueError):archive_uncommitted(run)
            self.assertTrue((run/'resume_latest.pth').exists())

    def test_direct_train_queue_finishes_all_seeds_before_first_test(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder);output=base/'out';(base/'data').mkdir()
            events=[];tested=set()
            def child(command,**kw):
                if Path(command[1]).name!='run_vast.py':return
                seed=int(command[command.index('--seed')+1])
                if '--train' in command:
                    self.assertIn('--validation-only',command)
                    make_committed(output,seed=seed);events.append(('train',seed))
                else:
                    self.assertIn('--evaluate-only',command)
                    self.assertEqual({s for mode,s in events if mode=='train'},{42,43})
                    tested.add(seed);events.append(('test',seed))
            def evaluated(run,status):
                return bool(status and int(run.parent.name.split('_')[-1]) in tested)
            # This test checks scheduling; all1344-file integrity is covered separately.
            with patch.object(queue,'verify_package'),patch.object(queue,'run_checked',side_effect=child),patch.object(queue,'evaluated',side_effect=evaluated),patch.object(queue,'summarize',return_value={'complete_study':False}):
                result=queue.main(['--data-root',str(base/'data'),'--output-root',str(output),
                                  '--runtime-root',str(base/'runtime'),'--total-hours','1','--seeds','42','43','--train'])
            self.assertEqual(result,0)
            self.assertEqual(events,[('train',42),('train',43),('test',42),('test',43)])

    def test_standalone_backup_does_not_need_train_deadline(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            with patch.object(ops,'verify_package'),patch.object(ops,'export_history'),patch.object(ops,'backup') as backup:
                result=ops.main(['backup','--workspace',str(root),'--output-root',str(root/'out'),
                                 '--data-root',str(root/'data'),'--runtime-root',str(root/'runtime')])
            self.assertEqual(result,0);backup.assert_called_once()

    def test_checksum_and_backup_respect_deadline(self):
        from process_control import DeadlineExceeded
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);path=root/'bytes';path.write_bytes(b'fixture')
            with self.assertRaises(DeadlineExceeded):ops.digest(path,time.time()-1)
            with self.assertRaises(DeadlineExceeded):ops.backup(root,root,deadline=time.time()-1)
            self.assertEqual(path.read_bytes(),b'fixture')

    def test_nested_supervision_does_not_start_new_group(self):
        import process_control as control
        class Fake:
            pid=123456
            def wait(self,**kw):return 0
            def poll(self):return 0
        # Linux branch checked structurally here; real signals remain a target-host test.
        with patch.object(control.os,'name','posix'),patch.object(control.subprocess,'Popen',return_value=Fake()) as popen,patch.object(control,'stop_tree'):
            control.run_checked(['fixture'],env={control.GROUP_ENV:'1'})
        self.assertFalse(popen.call_args.kwargs['start_new_session'])

    @unittest.skipUnless(os.name=='nt','Windows job-object regression')
    def test_windows_parent_exit_cleans_descendants(self):
        from test_safety import tree_command,clean_env
        import process_control as control
        with tempfile.TemporaryDirectory() as folder:
            heartbeat=Path(folder)/'heartbeat'
            control.run_checked(tree_command(heartbeat,exit_parent=True),env=clean_env(),deadline=time.time()+10)
            before=heartbeat.read_text();time.sleep(.4)
            self.assertEqual(heartbeat.read_text(),before)


if __name__=='__main__':unittest.main(verbosity=2)
