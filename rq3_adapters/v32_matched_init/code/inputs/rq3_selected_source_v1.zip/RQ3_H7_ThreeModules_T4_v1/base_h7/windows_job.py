"""Windows-only child ownership using kill-on-close Job Objects (no taskkill shell)."""
import ctypes
import time
from ctypes import wintypes


class ChildJob:
    def __init__(self,process):
        size=ctypes.c_size_t
        class Basic(ctypes.Structure):
            _fields_=[('PerProcessUserTimeLimit',ctypes.c_longlong),('PerJobUserTimeLimit',ctypes.c_longlong),
                      ('LimitFlags',wintypes.DWORD),('MinimumWorkingSetSize',size),('MaximumWorkingSetSize',size),
                      ('ActiveProcessLimit',wintypes.DWORD),('Affinity',size),('PriorityClass',wintypes.DWORD),
                      ('SchedulingClass',wintypes.DWORD)]
        class IO(ctypes.Structure):
            _fields_=[(name,ctypes.c_ulonglong) for name in ('ReadOperationCount','WriteOperationCount',
                       'OtherOperationCount','ReadTransferCount','WriteTransferCount','OtherTransferCount')]
        class Limits(ctypes.Structure):
            _fields_=[('BasicLimitInformation',Basic),('IoInfo',IO),('ProcessMemoryLimit',size),
                      ('JobMemoryLimit',size),('PeakProcessMemoryUsed',size),('PeakJobMemoryUsed',size)]
        self.api=ctypes.WinDLL('kernel32',use_last_error=True)
        self.api.CreateJobObjectW.argtypes=[ctypes.c_void_p,wintypes.LPCWSTR]
        self.api.CreateJobObjectW.restype=wintypes.HANDLE
        self.api.SetInformationJobObject.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD]
        self.api.SetInformationJobObject.restype=wintypes.BOOL
        self.api.AssignProcessToJobObject.argtypes=[wintypes.HANDLE,wintypes.HANDLE]
        self.api.AssignProcessToJobObject.restype=wintypes.BOOL
        self.api.CloseHandle.argtypes=[wintypes.HANDLE];self.api.CloseHandle.restype=wintypes.BOOL
        self.api.TerminateJobObject.argtypes=[wintypes.HANDLE,wintypes.UINT]
        self.api.TerminateJobObject.restype=wintypes.BOOL
        self.api.QueryInformationJobObject.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD,ctypes.c_void_p]
        self.api.QueryInformationJobObject.restype=wintypes.BOOL
        self.handle=self.api.CreateJobObjectW(None,None)
        if not self.handle:raise ctypes.WinError(ctypes.get_last_error())
        try:
            info=Limits();info.BasicLimitInformation.LimitFlags=0x2000
            if not self.api.SetInformationJobObject(self.handle,9,ctypes.byref(info),ctypes.sizeof(info)):
                raise ctypes.WinError(ctypes.get_last_error())
            if not self.api.AssignProcessToJobObject(self.handle,wintypes.HANDLE(int(process._handle))):
                raise ctypes.WinError(ctypes.get_last_error())
        except BaseException:
            self.close();raise

    def close(self):
        if self.handle:
            handle,self.handle=self.handle,None
            terminated=self.api.TerminateJobObject(handle,1)
            error=ctypes.get_last_error() if not terminated else None
            if terminated:
                until=time.monotonic()+10
                while True:
                    buffer=(ctypes.c_byte*4096)()
                    ok=self.api.QueryInformationJobObject(handle,3,buffer,4096,None)
                    if not ok and ctypes.get_last_error()!=234:
                        error=ctypes.get_last_error();break
                    count=(wintypes.DWORD*2).from_buffer(buffer)[0]
                    if count==0:break
                    if time.monotonic()>=until:
                        error=1460;break
                    time.sleep(.02)
            closed=self.api.CloseHandle(handle)
            if error is not None:raise ctypes.WinError(error)
            if not closed:raise ctypes.WinError(ctypes.get_last_error())
