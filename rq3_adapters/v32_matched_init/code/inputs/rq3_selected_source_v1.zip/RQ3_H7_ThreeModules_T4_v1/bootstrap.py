"""Install the audited Linux research runtime without replacing notebook packages."""
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'base_h7'))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime-root', required=True)
    args = parser.parse_args()
    from setup_environment import setup_runtime
    report = setup_runtime(ROOT / 'base_h7', args.runtime_root, world_size=1)
    print('USE_PYTHON=' + report['python_executable'])
