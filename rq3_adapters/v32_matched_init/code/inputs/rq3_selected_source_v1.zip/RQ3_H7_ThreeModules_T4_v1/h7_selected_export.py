"""Read-only selected-H7 baseline validation; never pretend this can resume H7."""
import hashlib
import json
import math
import re
from pathlib import Path

APPROVED_EXPORTS = {
    42: '352a301dcbf563f516f68194731edb60a9d079dce5350863e43caa9614351235',
    43: '9212129fe83a80d176bb7b0d7a871f874b81cc3b22f74cb97116ffaaace11f66',
    44: 'b52e37cbc32b676cf02847bd682f4f4f276a20565de9b5dcd6f99013de9ef711',
}


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            value.update(block)
    return value.hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def object_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def verified_baseline(run, seed):
    run = Path(run).resolve()
    marker_path = run / 'selected_export.json'
    if type(seed) is not int or seed not in APPROVED_EXPORTS:
        raise ValueError('Require the three approved H7 seeds 42/43/44.')
    if sha(marker_path) != APPROVED_EXPORTS[seed]:
        raise ValueError('Unapproved/changed selected H7 export: ' + str(run))
    marker = load(marker_path)
    if marker.get('schema') != 'h7-selected-baseline-v1' or marker.get('seed') != seed:
        raise ValueError('Wrong selected-export schema/seed.')
    required_metadata = {'run_manifest.json', 'training_status.json', 'validation_history.jsonl',
                         'rq2_test_report.json', 'evaluation_complete.json'}
    files = marker.get('files', {})
    weights = set(files) - required_metadata
    if not required_metadata.issubset(files) or len(weights) != 1:
        raise ValueError('Selected export has an unexpected file inventory.')
    best = next(iter(weights))
    match = re.fullmatch(r'best_mAUC@_epoch_([1-9]|[1-4][0-9]|50)\.pth', best)
    if match is None:
        raise ValueError('Unsafe/unknown selected checkpoint name.')
    for name, expected in files.items():
        path = run / name
        if path.resolve().parent != run or not path.is_file() or sha(path) != expected:
            raise ValueError('Selected baseline file missing/changed: ' + name)
    contract = load(run / 'run_manifest.json')['contract']
    profile = contract.get('rq2', {})
    expected = dict(seed=seed, epochs=50, batch_per_gpu=2, effective_batch_size=16,
                    world_size=1, amp=True, source_commit='579376fa1d879f28a9d68c2565d1e449de24b666',
                    data_revision='7535d0656dac31d7da2846913bb69c6331d2a70a')
    if any(type(contract.get(k)) is not type(v) or contract[k] != v for k, v in expected.items()):
        raise ValueError('Wrong original H7 scientific contract.')
    for key, value in dict(history_tokens=7, warmup_tokens=25, target_tokens=30,
                           input_tokens=55, snippet_frames=5, native_frame_stride=3).items():
        if type(profile.get(key)) is not int or profile[key] != value:
            raise ValueError('Wrong original H7 sampling contract: ' + key)
    status = load(run / 'training_status.json')
    if (status.get('complete') is not True or status.get('completed_epochs') != 50
            or status.get('target_epochs') != 50 or status.get('best_checkpoint') != best):
        raise ValueError('Selected H7 baseline is not a completed 50-epoch run.')
    history = [json.loads(line) for line in (run / 'validation_history.jsonl').read_text().splitlines()
               if line.strip()]
    if [row.get('epoch') for row in history] != list(range(1, 51)):
        raise ValueError('Require all 50 original validation epochs exactly once.')
    scores = [row.get('metrics', {}).get('mAUC@') for row in history]
    if any(type(value) not in (int, float) or not math.isfinite(value) for value in scores):
        raise ValueError('Missing/nonfinite original checkpoint-selection metric.')
    if int(match.group(1)) != scores.index(max(scores)) + 1:
        raise ValueError('Checkpoint does not match original best validation full mAUC.')
    report = load(run / 'rq2_test_report.json')
    seal = load(run / 'evaluation_complete.json')
    if (report.get('complete') is not True or report.get('seed') != seed
            or report.get('selected_checkpoint') != best
            or report.get('checkpoint_sha256') != files[best]
            or seal.get('complete') is not True or seal.get('checkpoint_sha256') != files[best]
            or seal.get('files', {}).get('rq2_test_report.json') != files['rq2_test_report.json']):
        raise ValueError('Selected checkpoint and original report/seal disagree.')
    keys = ('protocol', 'source_commit', 'data_revision', 'epochs', 'batch_per_gpu',
            'effective_batch_size', 'world_size', 'amp', 'precision', 'loss', 'preprocessing', 'rq2')
    return dict(run=str(run), checkpoint=str(run / best), checkpoint_sha256=files[best],
                contract_sha256=object_sha(contract), recipe_sha256=object_sha({k: contract.get(k) for k in keys}),
                best_epoch_checkpoint=best, baseline_input_kind='selected_frozen_H7_export',
                selected_export_sha256=APPROVED_EXPORTS[seed], H7_training_resume_available=False)
