"""Reuse the audited H7 data/loss/evaluator without editing its source files."""
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import torch

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'base_h7'
os.environ['RQ2_VARIANT'] = 'medium_h7'
sys.path.insert(0, str(BASE))
import repro
from modules import ARMS

_base_config = repro.config


def strict_fp32():
    if os.environ.get('TORCH_ALLOW_TF32_CUBLAS_OVERRIDE') == '1':
        raise RuntimeError('Unset TORCH_ALLOW_TF32_CUBLAS_OVERRIDE=1.')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.set_float32_matmul_precision('highest')
    if torch.backends.cuda.matmul.allow_tf32 or torch.backends.cudnn.allow_tf32:
        raise RuntimeError('Strict FP32 guard failed.')


def extension_hashes():
    names = ('modules.py', 'plugin.py', 'integration.py', 'run_modules.py', 'study.py', 'analyze.py',
             'configs/protocol.json', 'h7_selected_export.py')
    return {name: repro.sha256(ROOT / name) for name in names}


def contract(settings):
    return dict(protocol='rq3-h7-three-modules-frozen-fp32-selected-v1', seed=settings['seed'],
                arm=settings['arm'], base_history=7, histories=[7, 13, 26],
                checkpoint_sha256=settings['h7_checkpoint_sha256'],
                h7_contract_sha256=settings['h7_contract_sha256'],
                data_revision=repro.DATA_REVISION, source_commit=repro.SOURCE_COMMIT,
                source_package_sha256=repro.sha256(BASE / 'PACKAGE_SHA256.json'),
                extension_hashes=extension_hashes(),
                spec=json.loads((ROOT / 'configs/protocol.json').read_text(encoding='utf-8')),
                encode_chunk=settings['encode_chunk'], runtime=settings['runtime_contract'])


def config(settings, source, data, phase='train'):
    from plugin import register
    # base config imports taa from the tracked source before constructing registries.
    cfg = _base_config(settings, source, data, phase)
    from mmengine.utils import import_modules_from_strings
    import_modules_from_strings(**cfg.custom_imports)
    register()
    arm = settings['arm']
    cfg.model.type = 'RQ3H7Recognizer'
    cfg.model.activation_checkpoint = False
    cfg.model.encode_chunk = settings['encode_chunk']
    cfg.model.cls_head.type = 'RQ3H7Head'
    cfg.model.cls_head.arm = 'm1' if arm == 'b0' else arm
    cfg.model.cls_head.width = 512
    cfg.optim_wrapper = dict(type='OptimWrapper',
        optimizer=dict(type='AdamW', lr=1e-4, weight_decay=1e-4),
        accumulative_counts=8, clip_grad=dict(max_norm=40., norm_type=2),
        paramwise_cfg=dict(custom_keys={'backbone': dict(lr_mult=0., decay_mult=0.),
                                      'cls_head.rnn': dict(lr_mult=0., decay_mult=0.),
                                      'cls_head.fc_cls': dict(lr_mult=0., decay_mult=0.)}))
    cfg.param_scheduler = [dict(type='MultiStepLR', by_epoch=True, milestones=[20, 40], gamma=.1)]
    cfg.custom_hooks.append(dict(type='RQ3StrictHook'))
    cfg.default_hooks.checkpoint.max_keep_ckpts = 1
    if phase == 'smoke' or not cfg.resume:
        cfg.load_from = settings['h7_checkpoint']
    return cfg


def install(settings):
    strict_fp32()
    repro.config = config
    repro.run_contract = contract
    import rq2_capture
    rq2_capture.run_contract = contract
    rq2_capture.encode_features = encode_temporal
    from rq2_profile import scientific_profile as old_profile
    def profile():
        value = old_profile()
        # Adapter H26 sees farther than the frozen H7 prediction path.
        value['maximum_native_frame_lookback'] = 87 if settings['arm'] in ('m1_m2', 'full') else 30
        return value
    rq2_capture.scientific_profile = profile


def encode_temporal(model, info, ends, pipeline, cache, settings):
    import rq2_capture
    from modules import pack_encoder
    chunks = []
    for start in range(0, len(ends), settings['encode_chunk']):
        rq2_capture.check_budget(settings)
        sample = rq2_capture.sample_for(info, ends[start:start + settings['encode_chunk']],
                                         pipeline, cache, context=False)
        batch = model.data_preprocessor(dict(inputs=[sample['inputs']],
                                       data_samples=[sample['data_samples']]), False)
        with torch.no_grad(), torch.autocast(device_type='cuda', enabled=False):
            f = model.backbone(batch['inputs'][0].float())
            if not isinstance(f, torch.Tensor) or f.ndim != 5:
                raise ValueError('Expected one temporal encoder map.')
            chunks.append(pack_encoder(f).squeeze(-1).squeeze(-1))
    return torch.cat(chunks)  # N,C,T+1; last column is original H7 static reduction.


def register_hook():
    from mmengine.hooks import Hook
    from mmengine.registry import HOOKS
    if HOOKS.get('RQ3StrictHook') is not None:
        return
    @HOOKS.register_module()
    class RQ3StrictHook(Hook):
        priority = 'VERY_HIGH'
        def before_train_epoch(self, runner):
            strict_fp32()
            runner.model.backbone.eval()
        def before_val(self, runner):
            strict_fp32()
        def before_test(self, runner):
            strict_fp32()
        def before_train_iter(self, runner, batch_idx, data_batch=None):
            strict_fp32()
        def after_train_iter(self, runner, batch_idx, data_batch=None, outputs=None):
            if outputs and any(not torch.isfinite(torch.as_tensor(v)).all()
                               for k, v in outputs.items() if 'loss' in k):
                raise FloatingPointError('Nonfinite loss; stop without publishing a result.')
            for p in runner.model.cls_head.adapter.parameters():
                if not torch.isfinite(p).all():
                    raise FloatingPointError('Nonfinite adapter parameter.')
            if any(p.grad is not None for p in runner.model.backbone.parameters()):
                raise RuntimeError('Frozen encoder unexpectedly received gradients.')
