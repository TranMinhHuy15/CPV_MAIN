"""MMAction integration. Frozen H7 path remains intact; only adapter parameters train."""
import torch
from modules import ThreeModules, pack_encoder

_registered = False


def register():
    global _registered
    if _registered:
        return
    from rq2_model import register as register_base, bounded_lstm
    from mmaction.registry import MODELS
    register_base()
    BaseHead = MODELS.get('RQ2Head')
    BaseRecognizer = MODELS.get('RQ2Recognizer')

    @MODELS.register_module()
    class RQ3H7Head(BaseHead):
        def __init__(self, arm='full', width=512, **kwargs):
            kwargs['history'] = 7
            super().__init__(**kwargs)
            self.adapter = ThreeModules(arm, channels=self.in_channels, width=width)
            self.rnn.requires_grad_(False)
            self.fc_cls.requires_grad_(False)
            self.baseline_only = False
            self.last_diagnostics = {}

        def train(self, mode=True):
            super().train(mode)
            self.rnn.eval()
            self.fc_cls.eval()
            # Baseline dropout must also remain off during adapter training.
            self.dropout.eval()
            return self

        def baseline(self, temporal):
            f = temporal[..., -1]
            with torch.no_grad():
                h = bounded_lstm(self.rnn, f.float(), 7)
                return self.fc_cls(h).squeeze(-1)

        def score_features(self, features):
            if features.ndim != 4 or features.shape[-1] < 2:
                raise ValueError('Require packed temporal features plus original static mean; old cache unsupported.')
            z0 = self.baseline(features)
            if self.baseline_only:
                return z0.reshape(-1)
            z, diag = self.adapter(features[..., :-1].float(), z0)
            self.last_diagnostics = {k: v.detach() for k, v in diag.items()
                                     if k in ('correction', 'raw')}
            return z.reshape(-1)

        def forward(self, x, rq2_batch=None, rq2_tokens=None, **kwargs):
            if x.ndim != 5 or x.shape[0] != rq2_batch * rq2_tokens:
                raise ValueError('Expected encoder map [B*L,C,T,1,1].')
            temporal = x.mean((-2, -1)).reshape(rq2_batch, rq2_tokens, self.in_channels, x.shape[2])
            return self.score_features(temporal)

    @MODELS.register_module()
    class RQ3H7Recognizer(BaseRecognizer):
        def __init__(self, encode_chunk=2, **kwargs):
            kwargs['activation_checkpoint'] = False
            super().__init__(**kwargs)
            if type(encode_chunk) is not int or encode_chunk < 1:
                raise ValueError('encode_chunk must be a positive integer.')
            self.encode_chunk = encode_chunk
            self.backbone.requires_grad_(False).eval()

        def train(self, mode=True):
            super().train(mode)
            self.backbone.eval()
            return self

        def extract_feat(self, inputs, stage='neck', data_samples=None, test_mode=False):
            batch, tokens = inputs.shape[:2]
            flat = inputs.reshape(-1, *inputs.shape[2:])
            chunks = []
            # No gradients/BN updates in encoder, even when Runner sets model.train().
            with torch.no_grad(), torch.autocast(device_type=flat.device.type, enabled=False):
                for start in range(0, len(flat), self.encode_chunk):
                    f = self.backbone(flat[start:start + self.encode_chunk].float())
                    if not isinstance(f, torch.Tensor) or f.ndim != 5:
                        raise ValueError('Require one [N,C,T,H,W] backbone map.')
                    chunks.append(pack_encoder(f))
            x = torch.cat(chunks)
            extra = dict(rq2_batch=batch, rq2_tokens=tokens)
            return (self.cls_head(x, **extra) if stage == 'head' else x), extra

    _registered = True
