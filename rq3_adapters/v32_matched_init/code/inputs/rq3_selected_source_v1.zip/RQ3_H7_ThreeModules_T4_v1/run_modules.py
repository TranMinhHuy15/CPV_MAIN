"""Single-GPU H7 module study. Prepare -> actual CUDA smoke -> train -> gated test."""
import argparse
import copy
import importlib.metadata
import json
import math
import os
from pathlib import Path
import shutil
import statistics
import sys
import time

from study import (ROOT, BASE, SEEDS, PROTOCOL, load, save, sha, verify_package,
                   validate_inputs, baseline_input, bind_study, recover,
                   require_smoke, require_complete)


def runtime():
    import torch
    if sys.platform != 'linux' or not shutil.which('ffprobe'):
        raise RuntimeError('Use Linux with ffmpeg/ffprobe installed BEFORE starting training.')
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA required for real prepare/smoke/train/evaluate. CPU tests are separate.')
    if (sys.version_info[:3] != (3, 8, 5) or torch.__version__ != '2.1.0+cu118'
            or torch.version.cuda != '11.8'):
        raise RuntimeError('Use the bundled isolated Torch2.1.0+cu118 runtime.')
    for name, version in (('mmengine', '0.10.7'), ('mmcv', '2.2.0')):
        if importlib.metadata.version(name) != version:
            raise RuntimeError('Wrong runtime: ' + name)
    torch.cuda.set_device(0)  # One selected GPU, even on a Kaggle T4x2 notebook.
    from mmcv.ops import nms
    boxes=torch.tensor([[0.,0.,10.,10.],[1.,1.,9.,9.]],device='cuda')
    _,keep=nms(boxes,torch.tensor([.9,.8],device='cuda'),.5)
    if keep.tolist()!=[0]:
        raise RuntimeError('MMCV CUDA extension preflight failed.')
    return dict(python=list(sys.version_info[:3]), torch=torch.__version__, cuda=torch.version.cuda,
                cudnn=torch.backends.cudnn.version(), gpu=torch.cuda.get_device_name(0),
                packages={n: importlib.metadata.version(n) for n in
                          ('mmengine', 'mmcv', 'numpy', 'pandas', 'scikit-learn', 'opencv-python')})


def shared_data(inputs, deadline):
    import repro
    out = Path(inputs['out_root']).resolve()
    shared = out / 'shared'
    shared.mkdir(parents=True, exist_ok=True)
    settings = dict(workspace=str(shared), input_root=str(BASE), data_root=inputs['data_root'],
                    verify_video_hashes=True, deadline=deadline)
    source = repro.prepare_source(settings)
    data = repro.prepare_data(settings, source)
    return shared, source, data


def link_directory(target, source):
    target, source = Path(target), Path(source).resolve()
    if target.is_symlink():
        if target.resolve() != source:
            raise ValueError('Existing workspace link differs: ' + str(target))
    elif target.exists():
        raise ValueError('Refusing to overwrite non-link directory: ' + str(target))
    else:
        target.symlink_to(source, target_is_directory=True)


def settings_for(inputs, baselines, shared, runtime_contract, arm, seed, deadline):
    workspace = Path(inputs['out_root']).resolve() / arm / ('seed_%d' % seed)
    workspace.mkdir(parents=True, exist_ok=True)
    for name in ('author_source', 'prepared_nexar'):
        link_directory(workspace / name, shared / name)
    base = baselines[str(seed)]
    return dict(workspace=str(workspace), input_root=str(BASE), data_root=inputs['data_root'],
                seed=seed, arm=arm, epochs=50, world_size=1, amp=False,
                batch_per_gpu=2, effective_batch_size=16, workers_per_gpu=0,
                verify_video_hashes=True, deadline=deadline, runtime_contract=runtime_contract,
                h7_checkpoint=base['checkpoint'], h7_checkpoint_sha256=base['checkpoint_sha256'],
                h7_contract_sha256=base['contract_sha256'], encode_chunk=inputs['encode_chunk'])


def build(settings, phase):
    import integration
    integration.install(settings)
    source, data = (Path(settings['workspace']) / n for n in ('author_source', 'prepared_nexar'))
    cfg = integration.config(settings, source, data, phase)
    integration.register_hook()
    from mmengine.runner import Runner
    os.environ['RISKPROP_RUN_DIR'] = cfg.work_dir
    cfg.dump(str(Path(settings['workspace']) / ('resolved_%s_config.py' % phase)))
    return Runner.from_cfg(cfg)


def load_weights(runner, checkpoint, baseline_only=False):
    import torch
    from mmengine.runner.checkpoint import load_checkpoint
    runner.model.init_weights()
    saved = torch.load(checkpoint, map_location='cpu', weights_only=False)
    state = saved.get('state_dict', saved)
    state = {k.removeprefix('module.') if hasattr(k, 'removeprefix') else
             (k[7:] if k.startswith('module.') else k): v for k, v in state.items()}
    expected = runner.model.state_dict()
    required = {k for k in expected if not k.startswith('cls_head.adapter.')}
    if (set(state) - set(expected) or not required.issubset(state)
            or any(state[k].shape != expected[k].shape for k in state)):
        raise ValueError('Checkpoint is incompatible with frozen H7 model.')
    load_checkpoint(runner.model, checkpoint, map_location='cpu', strict=False)
    runner.model.cls_head.baseline_only = baseline_only


def smoke(settings):
    import torch
    from integration import contract, strict_fp32
    runner = build(settings, 'smoke')
    load_weights(runner, settings['h7_checkpoint'])
    model = runner.model
    model.train()
    adapter = model.cls_head.adapter
    frozen = {n: v.detach().cpu().clone() for n, v in model.state_dict().items()
              if not n.startswith('cls_head.adapter.')}
    before = adapter.output.weight.detach().clone()
    seen = []
    handle = adapter.rnn.weight_hh_l0.register_hook(
        lambda g: seen.append(float(g.detach().abs().sum())))
    wrapper = runner.build_optim_wrapper(runner.optim_wrapper)
    actual_updates = [0]
    step = wrapper.optimizer.step
    def counted_step(*args, **kwargs):
        result = step(*args, **kwargs)
        actual_updates[0] += 1
        return result
    wrapper.optimizer.step = counted_step
    wrapper.initialize_count_status(model, init_counts=0, max_counts=24)
    iterator = iter(runner.train_dataloader)
    torch.cuda.reset_peak_memory_stats()
    initial, loss_rows = None, []
    start = time.monotonic()
    try:
        for i in range(24):
            if time.time() >= settings['deadline']:
                raise RuntimeError('Smoke deadline reached before three optimizer updates.')
            strict_fp32()
            batch = next(iterator)
            logs = model.train_step(batch, wrapper)
            d = model.cls_head.last_diagnostics
            if initial is None:
                initial = float(d['correction'].abs().max())
            row = {k: float(v) for k, v in logs.items() if 'loss' in k}
            if not row or not all(math.isfinite(v) for v in row.values()):
                raise FloatingPointError('Nonfinite/missing smoke losses.')
            loss_rows.append(row)
            print('SMOKE %s %d/24 updates=%d' % (settings['arm'], i + 1, actual_updates[0]), flush=True)
    finally:
        handle.remove()
    unchanged = all(torch.equal(v.cpu(), frozen[n]) for n, v in model.state_dict().items()
                    if n in frozen)
    changed = not torch.equal(before, adapter.output.weight.detach())
    receipt = dict(contract=contract(settings), optimizer_updates=actual_updates[0],
                   recurrent_gradient_seen=any(math.isfinite(v) and v > 0 for v in seen),
                   initial_correction_max=initial, trainable_change=changed,
                   frozen_parameters_unchanged=unchanged, losses=loss_rows,
                   peak_memory_bytes=torch.cuda.max_memory_allocated(), seconds=time.monotonic() - start,
                   scope='discarded real train-data smoke; not validation/test result')
    receipt['passed'] = (actual_updates[0] == 3 and receipt['recurrent_gradient_seen']
                         and initial == 0. and changed and unchanged)
    save(Path(settings['workspace']) / 'smoke_receipt.json', receipt)
    if not receipt['passed']:
        raise RuntimeError('Smoke failed; full training remains blocked.')
    del runner, model, frozen
    torch.cuda.empty_cache()


def train(settings):
    import torch
    from integration import contract
    run = Path(settings['workspace']) / 'run'
    if shutil.disk_usage(run.parent).free < 4 * 2**30:
        raise RuntimeError('Need at least 4 GiB free for atomic checkpoint/snapshot commits.')
    expected = contract(settings)
    recover(run, expected)
    if (run / 'training_status.json').exists() and load(run / 'training_status.json')['complete']:
        print('ALREADY_COMPLETE', run, flush=True)
        return
    if (run / 'run_manifest.json').exists() and not (run / 'training_status.json').exists():
        from training_state import archive_uncommitted
        archive_uncommitted(run)
    run.mkdir(parents=True, exist_ok=True)
    save(run / 'run_manifest.json', dict(contract=expected))
    save(Path(settings['workspace']) / 'settings.json', settings)
    runner = build(settings, 'train')
    if not runner.cfg.resume:
        # Validate actual state keys before Runner's normal initialization/load path.
        load_weights(runner, settings['h7_checkpoint'])
    runner.train()
    del runner
    torch.cuda.empty_cache()


def evaluate_one(settings, baseline=False):
    import torch
    from integration import contract
    run = Path(settings['workspace']) / 'run'
    run.mkdir(parents=True, exist_ok=True)
    if baseline:
        checkpoint = Path(settings['h7_checkpoint'])
        target = run / checkpoint.name
        if not target.exists():
            target.symlink_to(checkpoint)
        if target.resolve() != checkpoint.resolve() or sha(target) != settings['h7_checkpoint_sha256']:
            raise ValueError('Baseline checkpoint link mismatch.')
        save(run / 'run_manifest.json', dict(contract=contract(settings), reused_original_H7=True))
        save(run / 'training_status.json', dict(complete=True, completed_epochs=50, target_epochs=50,
             best_checkpoint=checkpoint.name, reused_original_H7=True, newly_trained=False))
    status = load(run / 'training_status.json')
    runner = build(settings, 'evaluate')
    load_weights(runner, str(run / status['best_checkpoint']), baseline_only=baseline)
    runner.model.eval()
    import rq2_capture
    result = rq2_capture.capture_and_report(settings, runner.model)
    save(run / 'rq3_h7_test_report.json', dict(result, arm=settings['arm'], seed=settings['seed'],
         baseline_reused=baseline, study_status='exploratory_after_prior_test_inspection'))
    del runner
    torch.cuda.empty_cache()


def summarize(inputs):
    rows = {}
    for arm in ['b0'] + inputs['arms']:
        values = [load(Path(inputs['out_root']) / arm / ('seed_%d' % s) /
                       'run/rq3_h7_test_report.json')['summary_metrics'] for s in SEEDS]
        rows[arm] = {k: dict(mean=statistics.mean(v[k] for v in values),
                             sample_sd=statistics.stdev(v[k] for v in values),
                             per_seed={str(s): v[k] for s, v in zip(SEEDS, values)}) for k in values[0]}
    contrasts = {}
    for arm in inputs['arms']:
        contrasts[arm + '-b0'] = {}
        for metric in rows[arm]:
            delta = [rows[arm][metric]['per_seed'][str(s)] - rows['b0'][metric]['per_seed'][str(s)] for s in SEEDS]
            contrasts[arm + '-b0'][metric] = dict(mean=statistics.mean(delta), per_seed=delta)
    save(Path(inputs['out_root']) / 'summary.json', dict(results=rows, contrasts=contrasts,
         paired_intervals='not computed by this launcher; use saved paired per-video curves',
         interpretation='exploratory; no significance or paper-win inferred from means'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', required=True)
    parser.add_argument('--mode', choices=('prepare', 'smoke', 'train', 'evaluate'), required=True)
    parser.add_argument('--hours', type=float, required=True)
    args = parser.parse_args()
    if not math.isfinite(args.hours) or args.hours <= 0:
        parser.error('--hours must be finite and positive.')
    verify_package()
    inputs = validate_inputs(load(args.inputs))
    deadline = time.time() + args.hours * 3600
    baselines = {str(s): baseline_input(inputs['h7_runs'][str(s)], s) for s in SEEDS}
    if len({v['recipe_sha256'] for v in baselines.values()}) != 1:
        raise ValueError('The three H7 baseline seeds do not share the same recorded scientific recipe.')
    run_runtime = runtime()
    import integration
    integration.strict_fp32()
    value = dict(inputs=inputs, baselines=baselines, runtime=run_runtime,
                 code=integration.extension_hashes(), protocol=PROTOCOL)
    out = Path(inputs['out_root']).resolve()
    out.mkdir(parents=True, exist_ok=True)
    from process_control import exclusive_job
    with exclusive_job(out / '.study.lock'):
        bind_study(out, value)
        shared, source, data = shared_data(inputs, deadline)
        settings = {(a, s): settings_for(inputs, baselines, shared, run_runtime, a, s, deadline)
                    for a in inputs['arms'] for s in SEEDS}
        from integration import contract
        contracts = {key: contract(v) for key, v in settings.items()}
        if args.mode == 'prepare':
            for v in settings.values():
                save(Path(v['workspace']) / 'settings.json', v)
            print('PREPARED. Next: --mode smoke. No model was trained.', flush=True)
        elif args.mode == 'smoke':
            for arm in inputs['arms']:
                smoke(settings[(arm, 42)])
        elif args.mode == 'train':
            for arm in inputs['arms']:
                require_smoke(out, arm, contracts[(arm, 42)])
            for seed in SEEDS:
                for arm in inputs['arms']:
                    if time.time() + 900 >= deadline:
                        print('SESSION_BUDGET_STOP: rerun same command to resume. Billing is still active.', flush=True)
                        return
                    train(settings[(arm, seed)])
                    status = load(out / arm / ('seed_%d' % seed) / 'run/training_status.json')
                    if not status['complete']:
                        print('PARTIAL: resume same command; test remains locked.', flush=True)
                        return
        else:
            require_complete(out, inputs['arms'], contracts)
            for seed in SEEDS:
                b0 = settings_for(inputs, baselines, shared, run_runtime, 'b0', seed, deadline)
                evaluate_one(b0, baseline=True)
                for arm in inputs['arms']:
                    evaluate_one(settings[(arm, seed)])
            summarize(inputs)


if __name__ == '__main__':
    main()
