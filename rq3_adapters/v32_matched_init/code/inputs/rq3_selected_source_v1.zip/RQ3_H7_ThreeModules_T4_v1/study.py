"""Study contracts, immutable inputs and completed-run gates. No CUDA imports."""
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'base_h7'
sys.path.insert(0, str(BASE))
from training_state import assert_committed
from checkpoint_safety import restore_snapshot

SEEDS = (42, 43, 44)
ARMS = ('m1', 'm1_m2', 'm1_m3', 'full')
PROTOCOL = 'rq3-h7-three-modules-frozen-fp32-selected-v1'


def load(path):
    with Path(path).open(encoding='utf-8-sig') as stream:
        return json.load(stream)


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            value.update(block)
    return value.hexdigest()


def object_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=str(path.parent))
    try:
        with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
            json.dump(value, stream, indent=2, allow_nan=False, ensure_ascii=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def verify_package():
    manifest = load(ROOT / 'PACKAGE_SHA256.json')
    for name, expected in manifest.items():
        path = ROOT / name
        if not path.is_file() or sha(path) != expected:
            raise ValueError('Package changed: ' + name)
    return sha(ROOT / 'PACKAGE_SHA256.json')


def validate_inputs(value):
    if set(value) != {'data_root', 'out_root', 'h7_runs', 'arms', 'encode_chunk'}:
        raise ValueError('Use exactly the fields in configs/inputs.example.json.')
    arms = value['arms']
    if not isinstance(arms, list) or not arms or len(set(arms)) != len(arms) or any(a not in ARMS for a in arms):
        raise ValueError('Unknown/duplicate arms. H1/H3/H5 are not supported.')
    if 'full' not in arms:
        raise ValueError('Declared study must include primary arm full.')
    if type(value['encode_chunk']) is not int or not 1 <= value['encode_chunk'] <= 16:
        raise ValueError('encode_chunk must be an integer in [1,16]; T4 default=2.')
    if not isinstance(value['h7_runs'], dict) or set(value['h7_runs']) != {'42', '43', '44'}:
        raise ValueError('Require all three predetermined H7 seeds 42/43/44.')
    data, out = Path(value['data_root']).resolve(), Path(value['out_root']).resolve()
    if data == out or data in out.parents or out in data.parents:
        raise ValueError('Dataset and new outputs must be separate trees.')
    for path in value['h7_runs'].values():
        run = Path(path).resolve()
        if out == run or out in run.parents or run in out.parents:
            raise ValueError('New outputs cannot overlap original H7 runs.')
    return value


def baseline_input(run, seed):
    run = Path(run).resolve()
    if (run / "selected_export.json").is_file():
        from h7_selected_export import verified_baseline
        return verified_baseline(run, seed)
    if not run.is_dir():
        raise FileNotFoundError('Attach complete H7 run folder: ' + str(run))
    contract = load(run / 'run_manifest.json')['contract']
    profile = contract.get('rq2', {})
    if (contract.get('seed') != seed or profile.get('history_tokens') != 7
            or profile.get('warmup_tokens') != 25 or profile.get('target_tokens') != 30
            or profile.get('snippet_frames') != 5 or profile.get('native_frame_stride') != 3
            or contract.get('data_revision') != '7535d0656dac31d7da2846913bb69c6331d2a70a'):
        raise ValueError('Wrong H7 seed/sampling/data contract: ' + str(run))
    status = load(run / 'training_status.json')
    assert_committed(run, status, require_complete=True)  # Read-only: never repair user's source run.
    checkpoint = run / status['best_checkpoint']
    scientific_keys=('protocol','source_commit','data_revision','epochs','batch_per_gpu',
                     'effective_batch_size','world_size','amp','precision','loss','preprocessing','rq2')
    recipe={k:contract.get(k) for k in scientific_keys}
    return dict(run=str(run), checkpoint=str(checkpoint), checkpoint_sha256=sha(checkpoint),
                contract_sha256=object_sha(contract), recipe_sha256=object_sha(recipe),
                best_epoch_checkpoint=status['best_checkpoint'])


def bind_study(out, value):
    path = Path(out) / 'study_contract.json'
    if path.exists():
        if load(path) != value:
            raise ValueError('Study inputs/code/arms changed. Use a NEW out_root; existing outputs preserved.')
    else:
        save(path, value)


def recover(run, expected):
    run = Path(run)
    snapshot = run / 'safe_resume_snapshot.zip'
    if snapshot.exists():
        with zipfile.ZipFile(snapshot) as archive:
            saved = json.loads(archive.read('run_manifest.json'))['contract']
        if saved != expected:
            raise ValueError('Snapshot belongs to another arm/seed/config/runtime.')
        restore_snapshot(run, PROTOCOL, expected['seed'])
    manifest = run / 'run_manifest.json'
    if manifest.exists() and load(manifest).get('contract') != expected:
        raise ValueError('Existing run contract differs; refusing to overwrite.')
    if (run / 'training_status.json').exists():
        assert_committed(run, load(run / 'training_status.json'))


def require_smoke(out, arm, expected):
    row = load(Path(out) / arm / 'seed_42' / 'smoke_receipt.json')
    if (row.get('contract') != expected or row.get('passed') is not True
            or type(row.get('optimizer_updates')) is not int or row['optimizer_updates'] < 3
            or row.get('recurrent_gradient_seen') is not True or row.get('initial_correction_max') != 0.
            or row.get('trainable_change') is not True or row.get('frozen_parameters_unchanged') is not True):
        raise ValueError('Real-data smoke is missing/stale/insufficient for ' + arm)
    return row


def require_complete(out, arms, contracts):
    for seed in SEEDS:
        for arm in arms:
            run = Path(out) / arm / ('seed_%d' % seed) / 'run'
            recover(run, contracts[(arm, seed)])
            status = load(run / 'training_status.json')
            assert_committed(run, status, require_complete=True)
