from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analyze import paired_bootstrap


class AnalysisTests(unittest.TestCase):
    def test_paired_identical_predictions_zero_interval(self):
        labels=np.tile([0,1,0,1],3);groups=np.repeat([0,1,2],4)
        p=np.tile([.2,.8,.4,.7],(3,3))
        result=paired_bootstrap(labels,groups,p,p,draws=100)
        for value in result.values():
            self.assertEqual(value['delta'],0.)
            self.assertEqual(value['ci95'],[0.,0.])

    def test_missing_group_rejected(self):
        with self.assertRaises(ValueError):
            paired_bootstrap([0,1],[0,0],np.zeros((3,2)),np.zeros((3,2)),100)


if __name__=='__main__': unittest.main()
