import copy
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import integration


class Dot(dict):
    __getattr__=dict.__getitem__
    def __setattr__(self,key,value):self[key]=value


class ConfigTests(unittest.TestCase):
    def cfg(self,resume=False):
        return Dot(model=Dot(type='RQ2Recognizer',cls_head=Dot(history=7)),
                   custom_imports={'imports':[]},custom_hooks=[],
                   default_hooks=Dot(checkpoint=Dot(max_keep_ckpts=2)),
                   resume=resume,load_from='resume_latest.pth' if resume else 'kinetics.pth')

    def resolve(self,arm='full',resume=False,phase='train'):
        utils=types.ModuleType('mmengine.utils');utils.import_modules_from_strings=lambda **kwargs:None
        with patch.object(integration,'_base_config',return_value=self.cfg(resume)), \
             patch.dict(sys.modules,{'mmengine':types.ModuleType('mmengine'),'mmengine.utils':utils}), \
             patch('plugin.register',return_value=None):
            return integration.config({'arm':arm,'encode_chunk':2,'h7_checkpoint':'H7.pth'},None,None,phase)

    def test_all_arms_frozen_H7_and_fp32_optimizer(self):
        for arm in ('m1','m1_m2','m1_m3','full'):
            c=self.resolve(arm)
            self.assertEqual(c.model.type,'RQ3H7Recognizer')
            self.assertEqual(c.model.cls_head.arm,arm)
            self.assertEqual(c.model.cls_head.history,7)
            self.assertEqual(c.optim_wrapper['type'],'OptimWrapper')
            self.assertEqual(c.optim_wrapper['optimizer']['type'],'AdamW')
            self.assertEqual(c.optim_wrapper['optimizer']['lr'],1e-4)
            self.assertEqual(c.optim_wrapper['accumulative_counts'],8)
            self.assertEqual(c.load_from,'H7.pth')

    def test_resume_does_not_reload_original_H7(self):
        self.assertEqual(self.resolve(resume=True).load_from,'resume_latest.pth')

    def test_smoke_always_fresh_H7(self):
        self.assertEqual(self.resolve(resume=True,phase='smoke').load_from,'H7.pth')

    def test_baseline_arm_uses_m1_structure_without_H1(self):
        self.assertEqual(self.resolve('b0').model.cls_head.arm,'m1')

    def test_strict_precision_rejects_env_override(self):
        with patch.dict('os.environ',{'TORCH_ALLOW_TF32_CUBLAS_OVERRIDE':'1'}):
            with self.assertRaises(RuntimeError):integration.strict_fp32()


if __name__=='__main__':unittest.main()
