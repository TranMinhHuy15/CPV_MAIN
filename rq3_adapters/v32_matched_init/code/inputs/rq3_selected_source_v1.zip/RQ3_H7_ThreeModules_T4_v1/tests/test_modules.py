import copy
from pathlib import Path
import sys
import unittest
import torch
from torch import nn

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from modules import ARMS, ThreeModules, window, pack_encoder

torch.set_num_threads(2)


class ModuleTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(42)
        self.x = torch.randn(2, 55, 8, 5)
        self.base = torch.randn(2, 30)

    def model(self, arm='full'):
        return ThreeModules(arm, channels=8, width=8, dropout=0.)

    def test_initial_baseline_parity_all_arms(self):
        for arm in ARMS:
            m = self.model(arm)
            y, d = m(self.x, self.base)
            self.assertTrue(torch.equal(y, self.base))
            self.assertEqual(float(d['correction'].detach().abs().max()), 0.)

    def test_histories_and_oldest_first(self):
        x = torch.arange(55.).reshape(1, 55, 1)
        for h in (7, 13, 26):
            w = window(x, h)
            self.assertEqual(w.shape, (1, 30, h, 1))
            self.assertTrue(torch.equal(w[0, 0, :, 0], torch.arange(26-h, 26.)))
            self.assertEqual(float(w[0, -1, -1]), 54.)

    def test_reject_H1_H3_H5(self):
        for h in (1, 3, 5):
            with self.assertRaises(ValueError):
                window(self.x[..., 0], h)

    def test_no_future_leak_all_arms(self):
        for arm in ARMS:
            m = self.model(arm).eval()
            nn.init.normal_(m.output.weight)
            before = m(self.x, self.base)[0]
            changed = self.x.clone()
            changed[:, 31:] += torch.randn_like(changed[:, 31:]) * 100
            after = m(changed, self.base)[0]
            self.assertTrue(torch.allclose(before[:, :6], after[:, :6], atol=1e-6, rtol=0))

    def test_readouts_are_independent_resets(self):
        m = self.model().eval()
        u = m.token_features(self.x)
        c7, a7 = m.readout(u, 7)
        w = window(u, 7).reshape(60, 7, 8)
        states, _ = m.rnn(w)
        expected = (a7.reshape(60, 7, 1) * states).sum(1).reshape(2, 30, 8)
        self.assertTrue(torch.allclose(c7, expected))
        changed = u.clone()
        changed[:, :19] += 100
        # First H7 window reads indices 19..25; older inputs cannot alter it.
        self.assertTrue(torch.equal(m.readout(u, 7)[0][:, 0], m.readout(changed, 7)[0][:, 0]))

    def test_attention_and_scale_normalization(self):
        _, d = self.model()(self.x, self.base)
        self.assertEqual([a.shape[-1] for a in d['attention']], [7, 13, 26])
        for a in d['attention']:
            self.assertTrue(torch.allclose(a.sum(-1), torch.ones(2, 30), atol=1e-6))
        self.assertTrue(torch.allclose(d['scale_weights'].sum(-1), torch.ones(2, 30)))
        self.assertTrue(torch.all((d['gate']>0)&(d['gate']<1)))

    def test_zero_head_learns_then_recurrent_branch_learns(self):
        for arm in ARMS:
            m = self.model(arm)
            opt = torch.optim.AdamW(m.parameters(), lr=.01)
            seen = []
            for _ in range(3):
                opt.zero_grad()
                y, _ = m(self.x, self.base)
                nn.functional.binary_cross_entropy_with_logits(y, torch.ones_like(y)).backward()
                self.assertTrue(all(p.grad is None or torch.isfinite(p.grad).all() for p in m.parameters()))
                seen.append(float(m.rnn.weight_hh_l0.grad.abs().sum()))
                opt.step()
            self.assertEqual(seen[0], 0.)
            self.assertTrue(any(v > 0 for v in seen[1:]))

    def test_motion_branch_gets_gradient(self):
        m = self.model()
        nn.init.normal_(m.output.weight)
        m(self.x, self.base)[0].sum().backward()
        self.assertGreater(float(m.motion_net[0].weight.grad.abs().sum()), 0.)

    def test_bound_for_large_output(self):
        m = self.model()
        nn.init.constant_(m.output.bias, 10000.)
        out, d = m(self.x, self.base)
        self.assertLessEqual(float(d['correction'].detach().abs().max()), 1.)
        self.assertTrue(torch.isfinite(out).all())

    def test_reject_old_pooled_cache(self):
        with self.assertRaises(ValueError):
            self.model()(self.x.mean(-1), self.base)

    def test_motion_rejects_single_encoder_time_position(self):
        with self.assertRaises(ValueError):
            self.model()(self.x[..., :1], self.base)

    def test_reject_nonfinite(self):
        self.x[0, 0, 0, 0] = float('nan')
        with self.assertRaises(ValueError):
            self.model()(self.x, self.base)

    def test_motion_not_only_endpoint_difference(self):
        m = self.model('m1_m3').eval()
        # Same time mean and endpoints, different middle trajectory.
        a = torch.zeros(1, 55, 8, 5)
        b = a.clone()
        b[..., 1] = 1.
        b[..., 2] = -1.
        self.assertTrue(torch.equal(a.mean(-1), b.mean(-1)))
        self.assertTrue(torch.equal(a[..., -1]-a[..., 0], b[..., -1]-b[..., 0]))
        self.assertFalse(torch.allclose(m.token_features(a), m.token_features(b)))

    def test_serialized_state_roundtrip(self):
        import io
        m = self.model().eval()
        nn.init.normal_(m.output.weight)
        stream = io.BytesIO()
        torch.save(m.state_dict(), stream)
        stream.seek(0)
        restored = self.model().eval()
        restored.load_state_dict(torch.load(stream, weights_only=True))
        self.assertTrue(torch.equal(m(self.x, self.base)[0], restored(self.x, self.base)[0]))

    def test_input_baseline_detached_by_integration_contract(self):
        # New branch can backprop without retaining a frozen encoder graph.
        x = self.x.detach()
        m = self.model()
        m(x, self.base.detach())[0].sum().backward()
        self.assertIsNone(x.grad)

    def test_encoder_pack_preserves_original_reduction(self):
        x=torch.randn(4,8,5,7,7)
        packed=pack_encoder(x)
        self.assertEqual(packed.shape,(4,8,6,1,1))
        self.assertTrue(torch.equal(packed[:,:, -1,0,0],x.mean((2,3,4))))
        self.assertTrue(torch.equal(packed[:,:, :5,0,0],x.mean((-2,-1))))

    def test_zero_temporal_change_gives_zero_motion_residual(self):
        m=self.model('m1_m3').eval()
        f=torch.randn(2,55,8,1).expand(-1,-1,-1,5)
        expected=m.norm(m.proj(f.mean(-1)))
        self.assertTrue(torch.equal(m.token_features(f),expected))

    def test_age_term_only_decays_older_evidence(self):
        m=self.model().eval()
        nn.init.zeros_(m.query.weight);nn.init.zeros_(m.key.weight)
        _,a=m.readout(m.token_features(self.x),26)
        self.assertTrue(torch.all(a[...,1:]>=a[...,:-1]))


if __name__ == '__main__':
    unittest.main()
