"""Lightweight registry fixture exercises integration without pretending MMAction/CUDA ran."""
import importlib
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch
import torch
from torch import nn

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))


class Registry:
    def __init__(self): self.items={}
    def get(self,name): return self.items.get(name)
    def register_module(self):
        def add(cls): self.items[cls.__name__]=cls;return cls
        return add


class FakeHead(nn.Module):
    def __init__(self,in_channels=8,history=7,**kwargs):
        super().__init__();self.in_channels=in_channels;self.history=history
        self.rnn=nn.LSTM(in_channels,in_channels,batch_first=True)
        self.fc_cls=nn.Linear(in_channels,1);self.dropout=nn.Dropout(.9)


class FakeRecognizer(nn.Module):
    def __init__(self,activation_checkpoint=False,**kwargs):
        super().__init__()
        self.backbone=nn.Sequential(nn.Conv3d(3,8,1),nn.BatchNorm3d(8))


def bounded(rnn,f,history):
    from modules import window
    w=window(f,history);b,n,h,c=w.shape
    return rnn(w.reshape(b*n,h,c))[0][:,-1].reshape(b,n,c)


class PluginTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(42)
        self.registry=Registry();self.registry.items.update(RQ2Head=FakeHead,RQ2Recognizer=FakeRecognizer)
        registry=types.ModuleType('mmaction.registry');registry.MODELS=self.registry
        rq2=types.ModuleType('rq2_model');rq2.register=lambda:None;rq2.bounded_lstm=bounded
        self.patcher=patch.dict(sys.modules,{'mmaction':types.ModuleType('mmaction'),
            'mmaction.registry':registry,'rq2_model':rq2})
        self.patcher.start()
        import plugin
        plugin._registered=False;plugin.register()

    def tearDown(self):
        import plugin
        plugin._registered=False
        self.patcher.stop()

    def head(self,arm='full'):
        return self.registry.get('RQ3H7Head')(arm=arm,width=8,in_channels=8)

    def test_base_rnn_classifier_and_dropout_stay_frozen(self):
        h=self.head();h.train()
        self.assertFalse(h.rnn.training);self.assertFalse(h.fc_cls.training)
        self.assertFalse(h.dropout.training);self.assertTrue(h.adapter.training)
        self.assertTrue(all(not p.requires_grad for p in h.rnn.parameters()))

    def test_head_baseline_is_exact_frozen_H7(self):
        h=self.head().eval();f=torch.randn(2,55,8,5)
        with torch.no_grad():
            expected=h.fc_cls(bounded(h.rnn,f[...,-1],7)).squeeze(-1)
        self.assertTrue(torch.equal(h.score_features(f).reshape(2,30),expected))

    def test_head_spatial_pooling_preserves_time(self):
        from modules import pack_encoder
        h=self.head().eval();x=pack_encoder(torch.randn(110,8,5,3,3))
        observed=[]
        handle=h.adapter.register_forward_pre_hook(lambda m,args:observed.append(args[0].shape))
        h(x,rq2_batch=2,rq2_tokens=55);handle.remove()
        self.assertEqual(observed,[torch.Size([2,55,8,5])])

    def test_recognizer_backbone_no_gradient_or_BN_change(self):
        m=self.registry.get('RQ3H7Recognizer')(encode_chunk=2);m.train()
        before=m.backbone[1].running_mean.clone()
        x=torch.randn(1,55,3,5,3,3,requires_grad=True)
        f,extra=m.extract_feat(x)
        self.assertEqual(f.shape,(55,8,6,1,1));self.assertFalse(f.requires_grad)
        self.assertFalse(m.backbone.training)
        self.assertTrue(torch.equal(before,m.backbone[1].running_mean))
        self.assertEqual(extra,{'rq2_batch':1,'rq2_tokens':55})

    def test_gradient_only_adapter(self):
        h=self.head();h.train();f=torch.randn(2,55,8,5)
        nn.init.normal_(h.adapter.output.weight)
        h.score_features(f).sum().backward()
        self.assertTrue(all(p.grad is None for p in h.rnn.parameters()))
        self.assertTrue(all(p.grad is None for p in h.fc_cls.parameters()))
        self.assertGreater(float(h.adapter.rnn.weight_hh_l0.grad.abs().sum()),0.)

    def test_old_cache_rejected_when_motion_enabled(self):
        with self.assertRaises(ValueError): self.head().score_features(torch.randn(2,55,8))

    def test_baseline_only_ignores_adapter_weights(self):
        h=self.head();h.eval();f=torch.randn(2,55,8,5)
        expected=h.baseline(f).reshape(-1)
        nn.init.constant_(h.adapter.output.bias,100)
        h.baseline_only=True
        self.assertTrue(torch.equal(h.score_features(f),expected))


if __name__=='__main__': unittest.main()
