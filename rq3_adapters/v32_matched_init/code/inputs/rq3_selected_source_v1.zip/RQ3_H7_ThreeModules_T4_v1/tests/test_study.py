import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from study import (load, save, validate_inputs, bind_study, require_smoke,
                   baseline_input, recover, require_complete, PROTOCOL)


class StudyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def inputs(self):
        return dict(data_root=str(self.root/'data'), out_root=str(self.root/'out'),
                    h7_runs={str(s):str(self.root/('h7_%s'%s)) for s in (42,43,44)},
                    arms=['full'], encode_chunk=2)

    def test_inputs_valid(self):
        validate_inputs(self.inputs())

    def test_reject_missing_seed(self):
        x = self.inputs(); del x['h7_runs']['44']
        with self.assertRaises(ValueError): validate_inputs(x)

    def test_reject_duplicate_arms(self):
        x = self.inputs(); x['arms'] = ['full','full']
        with self.assertRaises(ValueError): validate_inputs(x)

    def test_reject_H1_arm(self):
        x = self.inputs(); x['arms'] = ['h1','full']
        with self.assertRaises(ValueError): validate_inputs(x)

    def test_reject_data_output_overlap(self):
        x = self.inputs(); x['out_root'] = str(Path(x['data_root'])/'outputs')
        with self.assertRaises(ValueError): validate_inputs(x)

    def test_reject_old_run_output_overlap(self):
        x = self.inputs(); x['out_root'] = x['h7_runs']['42']
        with self.assertRaises(ValueError): validate_inputs(x)

    def test_reject_chunk_zero(self):
        x = self.inputs(); x['encode_chunk'] = 0
        with self.assertRaises(ValueError): validate_inputs(x)

    def test_atomic_settings_replaces_corrupt_file(self):
        p = self.root/'settings.json'; p.write_text('{broken')
        save(p, {'a':1}); self.assertEqual(load(p), {'a':1})

    def test_atomic_save_failure_preserves_previous(self):
        p = self.root/'settings.json'; save(p, {'a':1})
        with self.assertRaises(ValueError): save(p, {'a':float('nan')})
        self.assertEqual(load(p), {'a':1})

    def test_changed_config_does_not_overwrite(self):
        bind_study(self.root, {'a':1})
        with self.assertRaises(ValueError): bind_study(self.root, {'a':2})
        self.assertEqual(load(self.root/'study_contract.json'), {'a':1})

    def receipt(self):
        return dict(contract={'seed':42}, passed=True, optimizer_updates=3,
                    recurrent_gradient_seen=True, initial_correction_max=0.,
                    trainable_change=True, frozen_parameters_unchanged=True)

    def test_smoke_requires_actual_updates(self):
        row=self.receipt(); row['optimizer_updates']=0
        save(self.root/'full/seed_42/smoke_receipt.json',row)
        with self.assertRaises(ValueError): require_smoke(self.root,'full',{'seed':42})

    def test_smoke_requires_gradient(self):
        row=self.receipt(); row['recurrent_gradient_seen']=False
        save(self.root/'full/seed_42/smoke_receipt.json',row)
        with self.assertRaises(ValueError): require_smoke(self.root,'full',{'seed':42})

    def test_smoke_rejects_other_config(self):
        save(self.root/'full/seed_42/smoke_receipt.json',self.receipt())
        with self.assertRaises(ValueError): require_smoke(self.root,'full',{'seed':43})

    def test_valid_smoke(self):
        save(self.root/'full/seed_42/smoke_receipt.json',self.receipt())
        self.assertTrue(require_smoke(self.root,'full',{'seed':42})['passed'])

    def test_missing_test_run_blocks_evaluation(self):
        with self.assertRaises(FileNotFoundError):
            require_complete(self.root, ['full'], {('full',s):{'seed':s} for s in (42,43,44)})

    def test_other_arm_resume_rejected(self):
        p=self.root/'run';save(p/'run_manifest.json',{'contract':{'arm':'m1'}})
        with self.assertRaises(ValueError): recover(p,{'arm':'full'})

    def test_h1_checkpoint_contract_rejected_even_if_same_tensor_shapes(self):
        p=self.root/'h1';p.mkdir()
        save(p/'run_manifest.json',{'contract':{'seed':42,'rq2':{'history_tokens':1}}})
        with self.assertRaises(ValueError): baseline_input(p,42)

    def test_valid_H7_records_recipe_without_modifying_source(self):
        p=self.root/'h7';p.mkdir()
        contract={'seed':42,'rq2':{'history_tokens':7,'warmup_tokens':25,'target_tokens':30,
                  'snippet_frames':5,'native_frame_stride':3},
                  'data_revision':'7535d0656dac31d7da2846913bb69c6331d2a70a'}
        save(p/'run_manifest.json',{'contract':contract})
        save(p/'training_status.json',{'best_checkpoint':'best.pth'})
        (p/'best.pth').write_bytes(b'fixture')
        before={f.name:f.read_bytes() for f in p.iterdir()}
        with patch('study.assert_committed',return_value=True):
            record=baseline_input(p,42)
        self.assertEqual(len(record['recipe_sha256']),64)
        self.assertEqual(before,{f.name:f.read_bytes() for f in p.iterdir()})


if __name__ == '__main__':
    unittest.main()
